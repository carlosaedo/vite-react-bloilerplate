import { Routes, Route, Navigate } from 'react-router-dom';
import Home from './components/pages/home';
import Page404 from './components/pages/page404';
import PersonalKitForm from './components/pages/personalkit';
import './App.css';

const apiData = {
  kitParts: {
    engineSeal: ['111111111111111111'],
    engine: ['222222222222222222'],
    carburatorSeal: ['33333333333333'],
    carburator: ['444444444444'],
    chassisSeal: ['555555555555555'],
    chassis: ['66666666666666'],
    exhaustSeal: ['77777777777777777'],
    exhaust: ['88888888888888'],
  },
  kitSetTires: [
    ['aaaaaaaaaaaaaaa', 'bbbbbbbbbbbbbb', 'cccccccccccccc', 'ddddddddddd'],
    ['eeeeeeeeeeee', 'fffffffffffffffffffffffff', 'gggggggggggggggggg', 'hhhhhhhhhhhhhhh'],
  ],
  validHelmet: true,
  validOverall: true,
  validTechnic: true,
  validGloves: true,
  validShoes: true,
  validBodyProtection: true,
  validPublicity: true,
};

function App() {
  console.log(`
                GET OUT OF THE CONSOLE!
     .@@@@@@@(
    @@       .@%
   ,@  (@&@,   @%
    @@ @@  @@. ,@
     (@@&    .@@@@.
       @@.        @&
        ,@@@      ,@
       @@@@@@%    @@                       ,&@@@@@@@@@@@@@@@@@/
       .@@@@@& %@@&                  @@@@@@@@                (@@@@@@
       @@(                      %@@@@%                             @@@@
      @@@                    @@@@/      @@                     &@@    @@@
      @@*                  @@@/                                        @@@
      @@.                @@@                                          &@@@
      @@(              @@@.                      ,(#@@@@@@@@@@@@@@@@@@@.
      @@@             @@@         %@@@@@@@@@@@@@@@@&#/,.          @@*
      .@@.           @@@                                          @@&
       @@@          @@@                                           @@@
        @@@        @@@                                            @@@
         @@#      (@@                                             %@@
         .@@&     @@#                                             /@@@@@
           @@@   @@@                                              .@@  @@@@
            /@@@@@@(@@                                             @@     @@@
                @@@@#,                                             @@      @@@
               .@@.                                                @@.    @@@
               @@@                                                 @@.  @@@/
               @@*                                                 @@.@@@*
              @@@                                                  @@@@@
              @@&                                                  @@@@@@.
             *@@                                                   @@@@@
             @@@                                                  .@@
             @@%                                                  ,@@
            ,@@                                                   *@@
            @@@                                                   /@@
            @@@                                                   #@@
            @@%                                                   %@@

  `);

  return (
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/kit' element={<PersonalKitForm initialData={apiData} />} />
      <Route path='*' element={<Navigate to='/404' replace />} />
      <Route path='/404' element={<Page404 />} />
    </Routes>
  );
}

export default App;
