const Home = () => {
  return (
    <>
      <div>
        <p>Home works</p>
      </div>
    </>
  );
};

export default Home;
