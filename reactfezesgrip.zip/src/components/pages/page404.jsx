const Page404 = () => {
  return (
    <>
      <div>
        <p>404 Page Not Found</p>
      </div>
    </>
  );
};

export default Page404;
